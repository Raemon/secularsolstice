# 500 Years From Today


500 years from today…

People won’t have to say goodbye anymore

I’ll drink tea with my great great grandchild

There will be everything for everyone, or close enough

We will have gazed at the sky under other suns

We will still have a future to build for