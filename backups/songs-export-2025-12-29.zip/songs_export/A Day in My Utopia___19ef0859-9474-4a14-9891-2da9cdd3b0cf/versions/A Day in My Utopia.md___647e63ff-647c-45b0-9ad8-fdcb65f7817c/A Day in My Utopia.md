# A Day in My Utopia
## by Ozy Brennan


When I wake up, the sun has risen and only one of my housemates is
still at home.

Our house is designed for group living. We each have our own
apartments with a bathroom and a private study/workroom, but the
kitchen and living room are shared. Architects designed the house to
maximize the possibility that housemates would run into each other in
the common areas, to promote incidental socialization. I don't know
exactly how they did it, because I haven't studied architecture yet.

Group houses are just one of the things our society has developed to
combat loneliness. Free time helps a lot; people don’t come home from
working two jobs too tired to do anything but watch TV. On the ground
floor of every apartment building are places for socializing:
coffeeshops and bowling alleys, nightclubs and board-game clubs,
toddler play spaces and libraries. Dating-site algorithms have been
honed to a science, and exist for platonic friends too. There are
special programs for people who have difficulty finding friends to
meet each other. And, frankly, one of the few things that’s scarce is
people who need to be helped: few people want to be befriended
altruistically, but it is better than having no friends at all, and it
often builds self-confidence and social skills that lead to people
becoming genuinely well-liked.

The one housemate who’s still here eats a muffin. We make small talk
about how work is going. He likes having more money than most people
do-- I think it mostly goes to hiring a maid once a week and to his
habit of leaving hundred-dollar bills on street corners to watch
people be ecstatic about finding them. So he works one of the
absolutely necessary jobs that most people won't do for free. He
monitors an automated shoe factory. It turns out tens of thousands of
shoes a day and has three employees.

I do some writing. I'm working on an extremely obscure fanfiction with
an audience of four people. But honestly becoming more famous would
just be tiring. I'm happy pleasing four of my friends and maybe
another person who stumbles across it and finds it wonderful.

I've put it off long enough: it's time to start preparing for the
festival. Sometimes it seems like every other weekend is a festival or
holiday of some sort, although of course you don’t help at every
one. Some people do nothing but plan and execute holiday festivals. It
seems incredibly tiring and stressful to me, but they just seem to
thrive on it.

The upcoming festival is for Geek Pride Day, and I'm signed up to
improv a character (they're from a modern movie, you wouldn't have
heard of it). I run through my spaced repetition deck of obscure facts
about my character's backstory; there's always one person who takes
pride in tripping you up. I note down a few more lines I might want to
try using; it's always a good idea to have some patter scripted out
for those routine conversations. My female housemate is making my
costume, which is good, because I don't have a head for crafts.

That evening, I check on my child in the artificial womb. He still
kind of looks like a freaky alien, but his vital signs are fine. I pet
the glass of his womb; although I know it's just a reflex reaction, I
imagine that he's waving at me.

Once my son is born, I'm going to set aside a lot of things I
currently do to focus on him. That isn't required, of course; children
grow up fine if their parents have lots of hobbies, or even a
full-time job of thirty hours a week. But I think it's really cool to
watch a person grow and show him all the good things about the world,
and I'd like to be able to focus on that. And it's not like my
projects can't be put on the backburner. I work a lot because I like
to, but most of my work doesn't pay; I live on my basic income.

Outside the hospital, I meet my girlfriend. She's a scientist. She's
free to work on whatever interests her, without having to scramble for
grant money or p-hack results out of her experiments; all her papers
are freely available to anyone who wants to read them.We gossip about
how the crowdfunding of CERN's latest particle accelerator is
going. Particle accelerators are expensive enough that they can't fund
it from their basic incomes, the way my girlfriend buys her
chemicals. But it looks like there are enough science fanboys with
spare cash that it'll get funded.

We walk two blocks and go past five or six excellent little
restaurants before eventually deciding we want to go to the salad
place. We live in a dense city, so there's a restaurant to cater to
any taste within walking distance. The salad place is owned by a guy
who really really likes making salads. There are also automated
restaurants with fast but predictably crappy food, produced by
machine. Of course you order with an app and pick up the food
yourself. Waiters get paid more than my housemate the factory manager
does, and thus are only employed at the sort of restaurant where the
bill comes to a thousand dollars or so.

Normally my girlfriend and I would take a late-night walk, but at
midnight tonight there's a show out on the water. It's pretty crowded,
and if you want a good seat you have to cough up a few hundred bucks;
people have enough disposable income that inherently scarce things get
really really expensive. But there's always a lot of standing room,
and it still looks beautiful from far away.

An orchestra plays. Lights glitter. Fountains shoot water into the
air. A mist descends, and rainbow lights dance across it; they resolve
into clips of nature, famous movies, the stars. Fireworks explode in
the background. The creators are free from worries about hunger,
thirst, homelessness, disease; they are free to do whatever they want,
and they choose to make beautiful things, to pursue excellence and art
for art's sake, to make things that others marvel at and to marvel at
others' creations in return.