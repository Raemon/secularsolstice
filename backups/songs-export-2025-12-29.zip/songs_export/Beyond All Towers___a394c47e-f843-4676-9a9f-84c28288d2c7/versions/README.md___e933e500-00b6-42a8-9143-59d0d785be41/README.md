#  Beyond All Towers
## By JRR Tolkien, Clamavi de Profundis, and Daniel Speyer
## Sam Gamgee alone in the Tower of Cirith Ungol

This song represents Sams despair (but not quite despair) at finding
Frodo again after Schlob stings him unconscious and the orcs drag him
away.

Clamavi de Profundis released [this
version](https://www.youtube.com/watch?v=Npio_2C1ASk).  They made
available (to patrons) sheet music for *the melody* but not the
harmony.

So this version takes that melody and attempts to reconstruct the
harmony around it, re-arranging for cello and guitar, and simplifying
as needed.