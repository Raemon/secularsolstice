#  Blackbird
## By The Beatles
## Encouragement to those who have been caged or wing-clipped

[Audio recording here](https://www.youtube.com/watch?v=Man4Xw8Xypo)