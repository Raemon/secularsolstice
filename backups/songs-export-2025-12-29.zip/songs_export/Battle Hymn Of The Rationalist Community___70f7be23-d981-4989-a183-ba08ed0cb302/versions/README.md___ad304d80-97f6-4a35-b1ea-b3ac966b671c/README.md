# Battle Hymn Of The Rationalist Community
## By Scott Alexandar (Lyrics)
## A triumphant celebration of truth and humanity

To the tune of [The Battle Hymn of the Republic](https://www.youtube.com/watch?v=Jy6AOGRsR80).

Pieces of this first appeared as [The Battle Hymn of the Republic of Letters](https://www.youtube.com/watch?v=2y-H2Ne_Djo) as part of the [Fermat's Last Stand Dungeons and Discourses campaign](https://slatestarcodex.com/2013/08/17/fermats-last-stand-soundtrack-and-adventure-log/).