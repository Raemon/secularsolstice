# Baby Genie
## By Raymond Arnold
## A simple AI metaphor

I'm not sure there exists a melody for this one.

Based on Eliezer's [Failed Utopia #4-2](http://lesswrong.com/lw/xu/failed_utopia_42/)