#  Ballad Of Smallpox Gone
## By Leslie Fish
## Celebrating this victory

Original recording [here](https://www.youtube.com/watch?v=32yPWJcq2AI)

Placing this one in the arc is a bit tricky.  The celebration of a modern accomplishment is more Morning, but the many considerations of remaining plagues don't quite fit with that.

An updated version of the lyrics was written for Bay Solstice 2022, and is presented below, with a corresponding [chord sheet](Ballad_of_Smallpox_Gone-chord-sheet.pdf). The original lyrics can be found [here](../lyrics.txt).
