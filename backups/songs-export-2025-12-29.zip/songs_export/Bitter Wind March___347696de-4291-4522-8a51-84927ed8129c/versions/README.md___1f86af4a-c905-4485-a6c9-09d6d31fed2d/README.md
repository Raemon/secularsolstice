# Bitter Wind March
## By Raymond Arnold
## A return to Bitter Wind Blown, but with determination to do something about it

Musically, this song is a reprise of [Bitter Wind
Blown](../../Bitter_Wind_Blown/gen/) and it has been known as "Bitter
Wind Reprise" in some documents.  Conceptually, it introduces a new
idea: that instead of asking the sun to save us, we're going to save
ourselves.

In orchestrating this song, it is important not to let it get too
militant or hopeful.  That would turn it into a Song of Dawn, and step
on Brighter Than Today's toes.

The [NYC 2016
Performance](https://www.youtube.com/watch?v=qmKx-NQ6iWU) is on Youtube

This song is available for sale via bandcamp in [all three albums](https://humanistculture.bandcamp.com/).



A [Bayesian Choir Performance](https://www.youtube.com/watch?v=C8fRlZUDpmk) of this song is on Youtube.