# And So It Goes
## By Billy Joel
## A lament of love, pain and acceptance

An outside song.  [Original music video](https://www.youtube.com/watch?v=FHO6a2H-pqY),  [Lyrics](https://genius.com/Billy-joel-and-so-it-goes-lyrics)